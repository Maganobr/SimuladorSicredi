package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Simulador {

	static WebDriver driver;
	
	public Simulador(WebDriver driver) {
		Simulador.driver = driver;
	}
	
	
	public void investimentoMinimo() {
		//Este cen�rio simula a inser��o de valores m�nimos aceitos nos campos valor aplicar, valor investir e tempo	
		WebElement valorAplicar  = driver.findElement(By.id("valorAplicar"));
		valorAplicar.sendKeys("20,00");
		WebElement valorInvestir = driver.findElement(By.id("valorInvestir"));
		valorInvestir.sendKeys("20,00");
		WebElement tempo         = driver.findElement(By.id("tempo"));
		tempo.sendKeys("1");
		
		WebElement btnSimular = driver.findElement(By.xpath("//button[@type='submit']"));
		btnSimular.click();
	}
	
	public void investimentoMaximo() {
		//Este cen�rio simula a inser��o de valores m�ximos aceitos nos campos valor aplicar, valor investir e tempo
		WebElement valorAplicar  = driver.findElement(By.id("valorAplicar"));
		valorAplicar.sendKeys("999.999,99");
		WebElement valorInvestir = driver.findElement(By.id("valorInvestir"));
		valorInvestir.sendKeys("999.999,99");
		WebElement tempo         = driver.findElement(By.id("tempo"));
		tempo.sendKeys("999");
		
		WebElement btnSimular = driver.findElement(By.xpath("//button[@type='submit']"));
		btnSimular.click();
	}
	
	public void investimentoNormal() {
		//Este cen�rio simula a inser��o de valores medianos nos campos valor aplicar, valor investir e tempo
		WebElement valorAplicar  = driver.findElement(By.id("valorAplicar"));
		valorAplicar.sendKeys("500,00");
		WebElement valorInvestir = driver.findElement(By.id("valorInvestir"));
		valorInvestir.sendKeys("250,00");
		WebElement tempo         = driver.findElement(By.id("tempo"));
		tempo.sendKeys("24");
		
		WebElement btnSimular = driver.findElement(By.xpath("//button[@type='submit']"));
		btnSimular.click();
	}
	
	public void investimentoInvalido() {
		//Este cen�rio simula a inser��o de valor inv�lidos nos campos valor aplicar, valor investir e tempo
		WebElement valorAplicar  = driver.findElement(By.id("valorAplicar"));
		valorAplicar.sendKeys("00,00");
		WebElement valorInvestir = driver.findElement(By.id("valorInvestir"));
		valorInvestir.sendKeys("00,00");
		WebElement tempo = driver.findElement(By.id("tempo"));
		tempo.sendKeys("0");
		valorAplicar.click();

	}
	//Este m�todo retorna o elemento de erro do valor investir na p�gina de simula��o
	public String validarValorInvestir() {
		return driver.findElement(By.id("valorInvestir-error")).getText();
	}
	//Este m�todo retorna o elemento de erro do valor aplicar na p�gina de simula��o
	public String validarValorAplicar() {
		return driver.findElement(By.xpath("//form[@id='formInvestimento']/div[2]/div[2]/label[2]")).getText();
	}
	
	//Este m�todo retorna o resultado do investimento simulado na p�gina de simula��o
	public String validarInvestimento() {
		return driver.findElement(By.xpath("//div/div/div[2]/span[2]")).getText();
		/*
		 	Como a hist�ria dizia para retornar a tabela, meu primeiro pensamento foi validar ela(conforme dado buscado abaixo)
		 	Mas se buscar ela, a valida��o fica mais complexa e pouco legivel, portanto preferi buscar somente 
		 	o resultado do investimento (conforme a consulta que est� acima
			return driver.findElement(By.xpath("//table")).getText();
		*/
	}
	
	//Este m�todo retorna o elemento de erro do tempo de investimento na p�gina de simula��o 
	public String validarTempo() {
		return driver.findElement(By.id("tempo-error")).getText();
	}
}
