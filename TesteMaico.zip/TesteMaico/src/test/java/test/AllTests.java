package test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ testeTempoInvalido.class, testeValorAplicarInvalido.class, testeValoresMaximos.class,
		testeValoresMinimos.class, testeValorInvestirInvalido.class, testeValorNormal.class })
public class AllTests {

}
