package test;

import static org.junit.Assert.*;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.Simulador;

public class testeValoresMinimos {

	//inst�nciando classe webdriver
	static WebDriver driver;
	static Simulador simulador;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.diver", "C:/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.sicredi.com.br/html/ferramenta/simulador-investimento-poupanca/");
		simulador = new Simulador(driver);
	}

	@Test
	public void testMinimo() {
		//o sleep foi inserido para o sistema aguardar o tempo da p�gina com a tabela de resultados ser carregada
		simulador.investimentoMinimo();
		try {
			Thread.sleep(500); 
		} catch (InterruptedException ex) { 
				System.out.println(ex); };
		//Este m�todo v�lida se o valor de resultado na tela � igual ao valor esperado
		assertEquals(simulador.validarInvestimento(), "R$ 40");
		
	}
		
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		driver.quit();
	}
}
